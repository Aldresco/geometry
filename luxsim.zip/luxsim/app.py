import time
import numpy as np
import streamlit as st
from core.surfaces import Segment2D, SurfaceType
from environments.scenes import EnvironmentLibrary
from simulation.engine import run_simulation
from simulation.source import Source2D, Source3D
from visualization.plotter import plot_scene

st.set_page_config(
    page_title="LUXSIM | Propagación geométrica",
    page_icon="✦",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    :root { --ink:#e5eefc; --muted:#9fb2cc; --line:#263750; --accent:#38bdf8; }
    .stApp { background:radial-gradient(ellipse at 70% 0%,#142b49 0%,#08111f 58%); color:var(--ink); }
    .block-container { max-width:1700px; padding-top:1.25rem; padding-bottom:2rem; }
    [data-testid="stSidebar"] { background:linear-gradient(180deg,#0b1728 0%,#0a1423 100%); border-right:1px solid #233650; }
      [data-testid="stSidebar"] * { color:#dce8f8; }
    .lux-brand { display:flex; align-items:center; gap:.7rem; margin-bottom:.35rem; }
    .lux-mark { display:flex; align-items:center; justify-content:center; width:44px; height:44px; border-radius:14px; background:linear-gradient(135deg,#06b6d4,#6366f1 55%,#a855f7); color:white; font-size:24px; font-weight:800; box-shadow:0 0 26px #06b6d455; }
    .lux-title { font-size:2.15rem; font-weight:850; letter-spacing:-.05em; color:#f8fbff; line-height:1.1; }
    .lux-subtitle { color:var(--muted); font-size:.96rem; margin:.35rem 0 1rem; }
    .lux-eyebrow { color:#67e8f9; text-transform:uppercase; letter-spacing:.16em; font-size:.7rem; font-weight:800; }
    .lux-section { font-size:1.08rem; font-weight:750; color:#e8f2ff; margin:.15rem 0; }
    div[data-testid="stMetric"] { background:linear-gradient(145deg,#12243a,#0e1b2d); border:1px solid #29405e; border-radius:16px; padding:12px 15px; box-shadow:0 6px 18px #02081726; }
    div[data-testid="stMetric"] label, div[data-testid="stMetric"] [data-testid="stMetricValue"] { color:#e8f2ff; }
    .stButton > button { min-height:2.65rem; border-radius:12px; font-weight:700; border:1px solid #36506f; transition:border-color .15s ease, transform .15s ease, box-shadow .15s ease; }
    .stButton > button:hover { border-color:#67e8f9; box-shadow:0 4px 16px #38bdf822; transform:translateY(-1px); }
    [data-testid="stDataFrame"], [data-testid="stTable"] { border:1px solid #263750; border-radius:14px; overflow:hidden; }
    [data-testid="stExpander"] { border:1px solid #263750; border-radius:14px; background:#0d1a2b66; }
    div[data-baseweb="slider"] [role="slider"] { box-shadow:0 0 0 3px #38bdf81c; }
    .stRadio [role="radiogroup"] { gap:.45rem; }
    .stButton > button[kind="primary"] { background:linear-gradient(100deg,#0891b2,#6366f1); border:0; color:white; box-shadow:0 5px 20px #0891b233; }
    div[data-baseweb="select"] > div, div[data-baseweb="input"] > div { background:#101f33; }
    hr { border-color:#263750; }
    </style>
    """,
    unsafe_allow_html=True,
)

ENVIRONMENTS_2D = {"A": "Circunferencia", "B": "Elipse", "C": "Recta reflectante"}
ENVIRONMENTS_3D = {"A": "Cilindro", "B": "Esfera", "C": "Elipsoide"}
MAX_RAYS = 72
MAX_BOUNCES = 40


def build_environment(env_id, mode):
    if mode == "3D":
        if env_id == "A":
            scene = EnvironmentLibrary.get_env_A_cylindrical(5, 10, 1.0, 8)
        elif env_id == "B":
            scene = EnvironmentLibrary.get_env_C_ellipsoid(5, 5, 5, 1.0, 2)
        elif env_id == "C":
            scene = EnvironmentLibrary.get_env_C_ellipsoid(6, 4, 8, 1.0, 2)
        else:
            raise ValueError("Escena 3D no disponible.")
    else:
        if env_id == "A":
            scene = EnvironmentLibrary.get_env_A_circular(5, 1.0, 3)
        elif env_id == "B":
            scene = EnvironmentLibrary.get_env_C_elliptical(6, 4, 1.0, 2.5)
        elif env_id == "C":
            scene = [Segment2D([-8.0, 0.0], [8.0, 0.0], 1.0)]
        else:
            raise ValueError("Escena 2D no disponible.")
    return [surface for surface in scene if surface.type != SurfaceType.RECEIVER]


def is_inside_figure(env_id, mode, position):
    x, y = position[:2]
    if mode == "2D":
        if env_id == "A":
            return x * x + y * y < 25.0 - 1e-8
        if env_id == "B":
            return (x / 6.0) ** 2 + (y / 4.0) ** 2 < 1.0 - 1e-8
        return False
    z = position[2]
    if env_id == "A":
        return x * x + y * y < 25.0 - 1e-8 and 1e-8 < z < 10.0 - 1e-8
    if env_id == "B":
        return x * x + y * y + z * z < 25.0 - 1e-8
    if env_id == "C":
        return (x / 6.0) ** 2 + (y / 4.0) ** 2 + (z / 8.0) ** 2 < 1.0 - 1e-8
    return False


def build_source(mode, position, angle_2d, azimuth_3d, elevation_3d, aperture, ray_count):
    if mode == "2D":
        return Source2D(position[:2], angle_2d, aperture, ray_count, 1000.0)

    azimuth = np.radians(azimuth_3d)
    elevation = np.radians(elevation_3d)
    direction = [
        np.cos(elevation) * np.cos(azimuth),
        np.cos(elevation) * np.sin(azimuth),
        np.sin(elevation),
    ]
    return Source3D(position[:3], direction, aperture, ray_count, 1000.0)


FORMULAS = {
    ("2D", "A"): ("Circunferencia", r"(x-h)^2+(y-k)^2=r^2"),
    ("2D", "B"): ("Elipse", r"\frac{(x-h)^2}{a^2}+\frac{(y-k)^2}{b^2}=1"),
    ("2D", "C"): ("Recta reflectante", r"\mathbf{p}(t)=\mathbf{p}_0+t\mathbf{d}"),
    ("3D", "A"): ("Cilindro", r"(x-h)^2+(y-k)^2=r^2,\quad z_{\min}\leq z\leq z_{\max}"),
    ("3D", "B"): ("Esfera", r"(x-h)^2+(y-k)^2+(z-l)^2=r^2"),
    ("3D", "C"): ("Elipsoide", r"\frac{(x-h)^2}{a^2}+\frac{(y-k)^2}{b^2}+\frac{(z-l)^2}{c^2}=1"),
}


def show_formulas(mode, env_id, angle_2d, azimuth_3d, elevation_3d, position, max_distance, ray_count, aperture, max_bounces):
    left, right = st.columns(2)
    figure_name, figure_formula = FORMULAS[(mode, env_id)]
    with left:
        st.markdown("**1. Figura geométrica**")
        st.caption(figure_name)
        st.latex(figure_formula)
        st.markdown("**2. Trayectoria del rayo**")
        if mode == "2D":
            st.latex(r"\mathbf{d}=(\cos\theta,\sin\theta)")
            st.caption(f"Dirección central actual: θ = {angle_2d}° · d = ({np.cos(np.radians(angle_2d)):.3f}, {np.sin(np.radians(angle_2d)):.3f})")
        else:
            st.latex(r"\mathbf{d}=(\cos\varphi\cos\theta,\cos\varphi\sin\theta,\sin\varphi)")
            st.caption(f"Azimut: {azimuth_3d}° · elevación: {elevation_3d}° · d = ({np.cos(np.radians(elevation_3d))*np.cos(np.radians(azimuth_3d)):.3f}, {np.cos(np.radians(elevation_3d))*np.sin(np.radians(azimuth_3d)):.3f}, {np.sin(np.radians(elevation_3d)):.3f})")
        st.latex(r"\mathbf{p}(t)=\mathbf{p}_0+t\mathbf{d},\quad t\geq0")
        st.caption("Fuente actual: P₀ = (" + ", ".join(f"{v:.2f}" for v in position) + f") · alcance = {max_distance} u · rayos = {ray_count} · apertura = {aperture}°")
    with right:
        st.markdown("**3. Intersección y rebote**")
        st.caption("Se busca el primer punto de la superficie que cumple la ecuación de la trayectoria.")
        st.latex(r"\mathbf{p}_i=\mathbf{p}_0+t_i\mathbf{d}")
        st.caption("En un rebote especular ideal, la componente normal de la dirección cambia de signo.")
        st.latex(r"\mathbf{d}_{\mathrm{salida}}=\mathbf{d}_{\mathrm{entrada}}-2(\mathbf{d}_{\mathrm{entrada}}\cdot\mathbf{n})\mathbf{n}")
        st.caption("Aquí n es la normal unitaria a la superficie en el punto de impacto.")
        st.markdown("**4. Límites de simulación**")
        st.latex(r"0 \leq s \leq L_{\max}, \qquad N_{\mathrm{rebotes}} \leq N_{\max}")
        st.caption(f"Alcance máximo: {max_distance} u · rebotes máximos: {max_bounces} · rayos: {ray_count} · apertura: {aperture}°")


if "config_signature" not in st.session_state:
    st.session_state.update({
        "rays": [],
        "surfaces": [],
        "max_sim_dist": 1.0,
        "config_signature": None,
        "animation_progress": 0.0,
        "animation_playing": False,
        "animation_last_tick": time.monotonic(),
        "validation_error": None,
        "has_applied_config": False,
    })

with st.sidebar:
    st.markdown(
        '<div class="lux-brand"><div class="lux-mark">✦</div><div><div class="lux-eyebrow">Laboratorio geométrico</div><div style="font-size:1.2rem;font-weight:800;color:#e5eefc;">LUXSIM</div></div></div>',
        unsafe_allow_html=True,
    )
    st.divider()
    st.markdown("**1 · Escena**")
    mode = st.radio("Dimensión", ["2D", "3D"], horizontal=True, key="ui_mode")
    options = ENVIRONMENTS_2D if mode == "2D" else ENVIRONMENTS_3D
    env_id = st.selectbox("Figura", list(options), format_func=lambda key: options[key], key=f"scene_{mode}")

    st.markdown("**2 · Ubicación de la fuente**")
    source_region = st.radio(
        "La fuente estará",
        ["Dentro de la figura", "Fuera de la figura"],
        horizontal=False,
        key=f"source_region_{mode}",
    )
    if mode == "2D":
        source_x = st.slider("Coordenada X", -8.0, 8.0, 0.0, 0.5, key="source_x_2d")
        source_y = st.slider("Coordenada Y", -8.0, 8.0, 2.0, 0.5, key="source_y_2d")
        position = [source_x, source_y]
        angle_2d = st.slider("Dirección central (°)", 0, 360, 270, 5, key="angle_2d")
        aperture = st.slider("Apertura angular (°)", 0, 360, 50, 5, key="aperture_2d")
        azimuth_3d, elevation_3d = 30, 55
    else:
        source_x = st.slider("Coordenada X", -8.0, 8.0, 0.0, 0.5, key="source_x_3d")
        source_y = st.slider("Coordenada Y", -8.0, 8.0, 0.0, 0.5, key="source_y_3d")
        source_z = st.slider("Coordenada Z", -3.0, 13.0, 1.0, 0.5, key="source_z_3d")
        position = [source_x, source_y, source_z]
        azimuth_3d = st.slider("Azimut (°)", 0, 360, 30, 5, key="azimuth_3d")
        elevation_3d = st.slider("Elevación (°)", -85, 85, 25, 5, key="elevation_3d")
        aperture = st.slider("Apertura angular 3D (°)", 0, 360, 100, 5, key="aperture_3d")
        angle_2d = 90

    ray_max = MAX_RAYS
    ray_default = 7
    ray_key = "ray_count_2d" if mode == "2D" else "ray_count_3d"
    ray_count = st.slider("Rayos emitidos", 1, ray_max, ray_default, 1, key=ray_key)
    max_distance = st.slider("Alcance máximo (unidades)", 5, 100, 30, 5, key="max_ray_distance")
    max_bounces = st.slider("Rebotes máximos", 1, MAX_BOUNCES, 20, 1, key="max_bounces")

    submitted = st.button("Simular", type="primary", use_container_width=True)

if submitted:
    st.session_state.has_applied_config = True

signature = (mode, env_id, source_region, tuple(position), angle_2d, azimuth_3d, elevation_3d, aperture, ray_count, max_distance, max_bounces)
inside = is_inside_figure(env_id, mode, position)
placement_ok = (mode == "2D" and env_id == "C") or (inside if source_region == "Dentro de la figura" else not inside)

# Los parámetros se previsualizan en cada cambio; el trazado analítico corre al pulsar el botón.
if submitted:
    if placement_ok:
        try:
            scene = build_environment(env_id, mode)
            source = build_source(mode, position, angle_2d, azimuth_3d, elevation_3d, aperture, ray_count)
            rays = run_simulation(source, scene, max_bounces, max_distance=float(max_distance))
            max_dist = float(max_distance)
            st.session_state.update({
                "rays": rays,
                "surfaces": scene,
                "max_sim_dist": max(max_dist, 0.01),
                "config_signature": signature,
                "animation_progress": 0.0,
                "animation_playing": True,
                "animation_last_tick": time.monotonic(),
                "validation_error": None,
            })
        except Exception as exc:
            st.session_state.validation_error = f"No se pudo calcular la escena: {exc}"
    else:
        st.session_state.config_signature = None
        st.session_state.animation_playing = False
        st.session_state.validation_error = "La posición de la fuente no coincide con la región seleccionada."

st.markdown(
    '<div class="lux-eyebrow">GEOMETRÍA ANALÍTICA · TRAZADO DE RAYOS</div>'
    '<div class="lux-title">LUXSIM <span style="color:#38bdf8;">/</span> Propagación y rebote</div>',
    unsafe_allow_html=True,
)

if not st.session_state.has_applied_config or (signature != st.session_state.config_signature and not st.session_state.validation_error):
    preview_scene = build_environment(env_id, mode)
    preview = plot_scene(preview_scene, [], is_3d=(mode == "3D"), source_position=position,
        beam_direction=(np.cos(np.radians(angle_2d)), np.sin(np.radians(angle_2d))) if mode == "2D" else None,
        beam_direction_3d=(np.cos(np.radians(elevation_3d)) * np.cos(np.radians(azimuth_3d)), np.cos(np.radians(elevation_3d)) * np.sin(np.radians(azimuth_3d)), np.sin(np.radians(elevation_3d))) if mode == "3D" else None,
        aperture_degrees=aperture, beam_length=float(max_distance), ray_count=ray_count)
    st.plotly_chart(preview, use_container_width=True, config={"displaylogo": False, "scrollZoom": True, "responsive": True})
elif st.session_state.validation_error:
    st.error(st.session_state.validation_error)
    preview_scene = build_environment(env_id, mode)
    preview = plot_scene(
        preview_scene,
        [],
        is_3d=(mode == "3D"),
        source_position=position,
        beam_direction=(np.cos(np.radians(angle_2d)), np.sin(np.radians(angle_2d))) if mode == "2D" else None,
        beam_direction_3d=(np.cos(np.radians(elevation_3d)) * np.cos(np.radians(azimuth_3d)), np.cos(np.radians(elevation_3d)) * np.sin(np.radians(azimuth_3d)), np.sin(np.radians(elevation_3d))) if mode == "3D" else None,
        aperture_degrees=aperture, beam_length=float(max_distance), ray_count=ray_count,
    )
    st.plotly_chart(
        preview,
        use_container_width=True,
        config={"displaylogo": False, "scrollZoom": True, "responsive": True},
        key=f"source_preview_{mode}_{env_id}",
    )
else:
    rays = st.session_state.rays
    c1, c2, c3 = st.columns(3)
    c1.metric("Rayos emitidos", len(rays))
    c2.metric("Alcance máximo", f"{max_distance} u")
    c3.metric("Rebotes máximos", max_bounces)
    selected_ray_index = st.selectbox("Inspeccionar recorrido", options=list(range(len(rays))), format_func=lambda i: f"Rayo {i + 1} · {len(rays[i].history) - 1} impactos", key="selected_ray_index") if rays else 0
    if rays:
        selected_ray = rays[selected_ray_index]
        history_rows = [{"Paso": i, "X": float(item[0][0]), "Y": float(item[0][1]), **({"Z": float(item[0][2])} if len(item[0]) > 2 else {}), "Distancia acumulada": float(item[3])} for i, item in enumerate(selected_ray.history)]
        st.dataframe(history_rows, use_container_width=True, hide_index=True)

    @st.fragment(run_every=0.10 if st.session_state.animation_playing else None)
    def animated_scene():
        controls = st.columns([1, 2, 4])
        if controls[0].button("Reiniciar", use_container_width=True):
            st.session_state.animation_progress = 0.0
            st.session_state.animation_last_tick = time.monotonic()
            st.session_state.animation_playing = True
            st.rerun()
        speed = controls[1].slider(
            "Velocidad",
            min_value=0.5,
            max_value=20.0,
            value=5.0,
            step=0.5,
            key="animation_speed_fragment",
        )
        controls[2].caption(f"Velocidad de propagación: {speed:.1f} unidades/s")

        if st.session_state.animation_playing:
            now = time.monotonic()
            elapsed = max(0.0, min(now - st.session_state.animation_last_tick, 0.25))
            st.session_state.animation_progress = min(
                st.session_state.max_sim_dist,
                st.session_state.animation_progress + elapsed * float(speed),
            )
            st.session_state.animation_last_tick = now
            if st.session_state.animation_progress >= st.session_state.max_sim_dist:
                st.session_state.animation_playing = False
                st.rerun()

        progress = float(st.session_state.animation_progress)
        st.markdown(f'<div class="lux-section">{options[env_id]} · vista {mode}</div>', unsafe_allow_html=True)
        fig = plot_scene(
            st.session_state.surfaces,
            st.session_state.rays,
            is_3d=(mode == "3D"),
            max_time_dist=progress,
            source_position=position,
            beam_direction=(np.cos(np.radians(angle_2d)), np.sin(np.radians(angle_2d))) if mode == "2D" else None,
            beam_direction_3d=(np.cos(np.radians(elevation_3d)) * np.cos(np.radians(azimuth_3d)), np.cos(np.radians(elevation_3d)) * np.sin(np.radians(azimuth_3d)), np.sin(np.radians(elevation_3d))) if mode == "3D" else None,
            aperture_degrees=aperture, beam_length=float(max_distance), ray_count=ray_count,
            selected_ray_index=selected_ray_index,
        )
        st.plotly_chart(
            fig,
            use_container_width=True,
            config={"displaylogo": False, "scrollZoom": True, "responsive": True},
            key=f"scene_plot_{mode}_{env_id}",
        )
    
    animated_scene()

    with st.expander("Conceptos y fórmulas", expanded=False):
        show_formulas(mode, env_id, angle_2d, azimuth_3d, elevation_3d, position, max_distance, ray_count, aperture, max_bounces)
        st.markdown("**Valores geométricos de la figura**")
        if mode == "2D" and env_id == "A":
            geometry_values = [{"Parámetro": "Centro (h, k)", "Valor aplicado": "(0, 0)"}, {"Parámetro": "Radio r", "Valor aplicado": "5 u"}]
        elif mode == "2D" and env_id == "B":
            geometry_values = [{"Parámetro": "Centro (h, k)", "Valor aplicado": "(0, 0)"}, {"Parámetro": "Semieje horizontal a", "Valor aplicado": "6 u"}, {"Parámetro": "Semieje vertical b", "Valor aplicado": "4 u"}]
        elif mode == "2D":
            geometry_values = [{"Parámetro": "Punto inicial", "Valor aplicado": "(-8, 0)"}, {"Parámetro": "Punto final", "Valor aplicado": "(8, 0)"}, {"Parámetro": "Longitud", "Valor aplicado": "16 u"}]
        elif env_id == "A":
            geometry_values = [{"Parámetro": "Centro de la base", "Valor aplicado": "(0, 0, 0)"}, {"Parámetro": "Radio r", "Valor aplicado": "5 u"}, {"Parámetro": "Altura h", "Valor aplicado": "10 u"}, {"Parámetro": "Intervalo z", "Valor aplicado": "[0, 10]"}]
        elif env_id == "B":
            geometry_values = [{"Parámetro": "Centro (h, k, l)", "Valor aplicado": "(0, 0, 0)"}, {"Parámetro": "Radio r", "Valor aplicado": "5 u"}]
        else:
            geometry_values = [{"Parámetro": "Centro (h, k, l)", "Valor aplicado": "(0, 0, 0)"}, {"Parámetro": "Semieje a", "Valor aplicado": "6 u"}, {"Parámetro": "Semieje b", "Valor aplicado": "4 u"}, {"Parámetro": "Semieje c", "Valor aplicado": "8 u"}]
        st.dataframe(geometry_values, use_container_width=True, hide_index=True)
        st.divider()